<stdlib5>
실제 개발에 사용될 Go 라이브러리 코드입니다.
모듈 임포트 부분에 약간 차이가 있습니다.
이 stdlib5 폴더가 Go src 모듈 폴더 안에 들어가야 합니다.

<stdlib5_windows>
윈도우 환경용 stdlib5 python 라이브러리 코드입니다.

<stdlib5_linux>
리눅스 환경용 stdlib5 python 라이브러리 코드입니다.

<GOROOT path>
C:/Program Files/Go/src/stdlib5/
/usr/lib/go-1.18/src/stdlib5/

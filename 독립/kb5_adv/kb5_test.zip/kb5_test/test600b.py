# test600b : image viewer

import time
import sys
import io
import multiprocessing as mp

import tkinter
from PIL import Image, ImageTk

import kaes
import kcom

def main():

    try:
        # 수신부
        addr = sys.argv[1]
        port, key = kcom.unpack(addr)
        k = kcom.client()
        k.port = port
        k.close = 30
        k.recieve()
        buffer = k.msg.split("\n")
        name = buffer[0]
        repl = int( buffer[1] )
        size = int( buffer[2] )

        idata = [b""] * repl
        for i in range(0, repl):
            time.sleep(0.07)
            idata[i] = k.recieve()

        idata = b"".join(idata)
        ifmt = name.lower()
        ifmt = ifmt[ifmt.rfind(".") + 1:]
        if len(idata) != size:
            raise Exception(f"size err {len(idata)}/{size}")
        k = kaes.funcbytes()
        idata = k.de(key, idata)

        # 변환부
        pimg = Image.open( io.BytesIO(idata) )
        iw, ih = pimg.size
        ratio = min(370 / iw, 370 / ih)
        sw, sh = int(iw * ratio), int(ih * ratio)
        rimg = pimg.resize( (sw, sh), Image.LANCZOS )
    except Exception as e:
        name = str(e)[0:15]

    # 표시부
    win = tkinter.Tk()
    win.title("VIEW : " + name)
    win.geometry("400x400+200+100")
    win.resizable(False, False)

    try:
        canvas = tkinter.Canvas(win, width=380, height=380)
        canvas.place(x=10, y=10)
        rpimg = ImageTk.PhotoImage(rimg)
        canvas.create_image(5, 5, anchor=tkinter.NW, image=rpimg)
    except:
        pass

    win.mainloop()

if __name__ == "__main__":
    time.sleep(0.5) #####
    mp.freeze_support()
    main()

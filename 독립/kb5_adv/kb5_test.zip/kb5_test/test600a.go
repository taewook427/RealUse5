package main

import (
	"bufio"
	"bytes"
	"crypto/rand"
	"fmt"
	"io/ioutil"
	"os"
	"os/exec"
	"stdlib5/kaes"
	"stdlib5/kcom"
	"stdlib5/kdb"
	"strconv"
	"strings"
	"time"

	"golang.org/x/exp/slices"
)

// test600 : boom

// 전역 변수 설정
var password []byte
var keyfile []byte
var hint []byte
var message string
var folders []string
var boomnum int
var filekeys map[string][]byte
var filenames []string

// 최초 초기화
func finit() []byte {
	password = []byte("0000")
	keyfile = kaes.Genkf("NoPathExists")
	hint = []byte("초기화 비밀번호 : 0000")
	message = "Kboom 사용을 환영합니다."
	folders = make([]string, 0)
	f, _ := ioutil.ReadDir("./")
	temp := make([]string, 0)
	for _, r := range f {
		if r.IsDir() && len(r.Name()) > 3 {
			temp = append(temp, r.Name())
		}
	}
	for _, r := range temp {
		if r[len(r)-3:] == "_en" {
			name := r[0 : len(r)-3]
			if slices.Contains(temp, name+"_de") {
				folders = append(folders, name)
			}
		}
	}
	boomnum = 104857600
	filekeys = make(map[string][]byte)

	t, err := ioutil.ReadFile("settings.webp")
	if err == nil {
		return t
	} else {
		tv := pkgsetting()
		ioutil.WriteFile("settings.webp", tv, 0666)
		return tv
	}
}

// 세팅 파일 패키징 (-> enc)
func pkgsetting() []byte {
	tbox0 := kdb.Init()
	tbox1 := kaes.Init0()
	tbox1.Msg = "Kboom settings file"

	temp := make([]string, 0)
	temp = append(temp, "msg = 0")
	temp = append(temp, "boom = 0")
	temp = append(temp, "num = 0")
	for i := 0; i < len(filekeys); i++ {
		temp = append(temp, fmt.Sprintf("%d.name = 0", i))
		temp = append(temp, fmt.Sprintf("%d.key = 0", i))
	}
	ts := strings.Join(temp, "\n")
	tbox0.Readstr(&ts)

	ts = "msg"
	tbox0.Fixdata(&ts, message)
	ts = "boom"
	tbox0.Fixdata(&ts, boomnum)
	ts = "num"
	tbox0.Fixdata(&ts, len(filekeys))
	count := 0
	for i, r := range filekeys {
		ts = fmt.Sprintf("%d.name", count)
		tbox0.Fixdata(&ts, i)
		ts = fmt.Sprintf("%d.key", count)
		tbox0.Fixdata(&ts, r)
		count = count + 1
	}
	ts = *tbox0.Writestr()

	return tbox1.En(password, keyfile, hint, []byte(ts))
}

// 세팅 파일 읽기 (0 : 성공, 1 : 실패)
func readpkg(enc []byte) (rtv int) {
	defer func() {
		if err := recover(); err != nil {
			rtv = 1
		}
	}()
	tbox0 := kdb.Init()
	tbox1 := kaes.Init0()
	h, _, stp := tbox1.View(enc)
	fmt.Println(string(h))
	pw := []byte(input("PW : "))
	txt := string(tbox1.De(pw, keyfile, enc, stp))
	hint = h
	password = pw

	tbox0.Readstr(&txt)
	ts := "msg"
	message = tbox0.Getdata(&ts).Dat6
	ts = "boom"
	boomnum = tbox0.Getdata(&ts).Dat2
	ts = "num"
	fnum := tbox0.Getdata(&ts).Dat2
	for j := 0; j < fnum; j++ {
		ts = fmt.Sprintf("%d.name", j)
		tname := tbox0.Getdata(&ts).Dat6
		ts = fmt.Sprintf("%d.key", j)
		tkey := tbox0.Getdata(&ts).Dat5
		filekeys[tname] = tkey
	}

	return 0
}

// 표준입력
func input(msg string) string {
	fmt.Print(msg)
	temp, _ := bufio.NewReader(os.Stdin).ReadString('\n')
	temp = strings.Replace(temp, "\n", "", -1)
	temp = strings.Replace(temp, "\r", "", -1)
	return temp
}

// 지연출력
func printlate(msg string, late float64) {
	slpt := time.Duration(late * 200)
	toptr := [5]string{msg, " .", " .", " .", " "}
	for _, r := range toptr {
		fmt.Print(r)
		time.Sleep(slpt * time.Millisecond)
	}
}

// 사진 전송
func transmit(name string, data []byte) {
	defer func() {
		if err := recover(); err != nil {
			fmt.Println("전송오류 : ", err)
		}
	}()
	temp := make([]byte, 3)
	rand.Read(temp)
	num := int(temp[0]) + 256*int(temp[1]) + 65536*int(temp[2])
	port := int(float64(num)/16777216*30000) + 10000 // 10000 ~ 40000
	key := kaes.Genrandom(8)                         // len 8
	realkey := bytes.Repeat(key, 6)                  // len 48
	addr := kcom.Pack(port, key)                     // port + key 8B

	tbox0 := kaes.Init2()
	togo := tbox0.En(realkey, data)
	buffer := make([][]byte, 0)
	num = len(togo) / 102400 // 전송 단위 100KiB
	for i := 0; i < num; i++ {
		buffer = append(buffer, togo[102400*i:102400*i+102400])
	}
	buffer = append(buffer, togo[102400*num:])
	fmt.Printf("ADDR(90s)   %s\n", addr)

	tbox1 := kcom.Initsvr()
	tbox1.Port = port
	tbox1.Close = 90
	tbox1.Msg = fmt.Sprintf("%s\n%d\n%d", name, len(buffer), len(togo))
	fmt.Print("transmit : [")
	tbox1.Send(make([]byte, 0))
	count := 0
	for i, r := range buffer {
		time.Sleep(time.Duration(30) * time.Millisecond)
		tbox1.Send(r)
		current := int(float64(i+1) / float64(len(buffer)) * 50)
		if count < current {
			fmt.Print(strings.Repeat("=", current-count))
			count = current
		}
	}
	fmt.Print("]\n")
}

// 뷰어 실행
func goviewer(addr string) {
	temp := exec.Command("python", "./test600b.py", addr) // 윈도우/리눅스 실행파일 차이 !!!!!
	temp.Run()
}

// 명령어 인터프리터
func interpret() (out []string) {
	defer func() {
		if err := recover(); err != nil {
			out = nil
		}
	}()
	fmt.Println("\nsend N   view N   config   clear   import   export N   status   boom")
	ts := strings.Split(input(">>> "), " ")
	temp := make([]string, 2)
	switch ts[0] {
	case "send":
		temp[0] = "send"
		_, err := strconv.Atoi(ts[1])
		if err == nil {
			temp[1] = ts[1]
		} else {
			return nil
		}
	case "view":
		temp[0] = "view"
		_, err := strconv.Atoi(ts[1])
		if err == nil {
			temp[1] = ts[1]
		} else {
			return nil
		}
	case "config":
		temp[0] = "config"
	case "clear":
		temp[0] = "clear"
	case "import":
		temp[0] = "import"
	case "export":
		temp[0] = "export"
		if ts[1] == "*" {
			temp[1] = "*"
		} else {
			_, err := strconv.Atoi(ts[1])
			if err == nil {
				temp[1] = ts[1]
			} else {
				return nil
			}
		}
	case "boom":
		temp[0] = "boom"
	case "status":
		temp[0] = "status"
	default:
		temp[0] = "exit"
	}
	return temp
}

// send N
func fsend(n int) {
	name := filenames[n]
	pos := strings.Index(name, "/")
	fo := name[0:pos]
	fn := name[pos+1:]
	f, _ := ioutil.ReadFile("./" + fo + "_en/" + fn)
	tbox := kaes.Init2()
	data := tbox.De(filekeys[name], f)
	fmt.Printf("전송 시작 : %s\n", name)
	transmit(name, data)
	fmt.Printf("전송 완료 : %s\n", name)
}

// view N
func fview(n int) {
	defer func() {
		if err := recover(); err != nil {
			fmt.Println("전송오류 : ", err)
		}
	}()

	// 파일 준비
	name := filenames[n]
	pos := strings.Index(name, "/")
	fo := name[0:pos]
	fn := name[pos+1:]
	f, _ := ioutil.ReadFile("./" + fo + "_en/" + fn)
	tbox0 := kaes.Init2()
	data := tbox0.De(filekeys[name], f)
	fmt.Printf("사진 보기 : %s\n", name)

	// 송신 준비
	temp := make([]byte, 3)
	rand.Read(temp)
	num := int(temp[0]) + 256*int(temp[1]) + 65536*int(temp[2])
	port := int(float64(num)/16777216*30000) + 10000 // 10000 ~ 40000
	key := kaes.Genrandom(8)                         // len 8
	realkey := bytes.Repeat(key, 6)                  // len 48
	addr := kcom.Pack(port, key)                     // port + key 8B

	// 암호화, 쪼개기
	togo := tbox0.En(realkey, data)
	buffer := make([][]byte, 0)
	num = len(togo) / 102400 // 전송 단위 100KiB
	for i := 0; i < num; i++ {
		buffer = append(buffer, togo[102400*i:102400*i+102400])
	}
	buffer = append(buffer, togo[102400*num:])

	// 뷰어 실행
	go goviewer(addr)

	// 전송
	tbox1 := kcom.Initsvr()
	tbox1.Port = port
	tbox1.Close = 90
	tbox1.Msg = fmt.Sprintf("%s\n%d\n%d", name, len(buffer), len(togo))
	fmt.Print("transmit : [")
	tbox1.Send(make([]byte, 0))
	count := 0
	for i, r := range buffer {
		time.Sleep(time.Duration(50) * time.Millisecond)
		tbox1.Send(r)
		current := int(float64(i+1) / float64(len(buffer)) * 50)
		if count < current {
			fmt.Print(strings.Repeat("=", current-count))
			count = current
		}
	}
	fmt.Print("]\n")
}

// config
func fconfig() {
	fmt.Println("<디버그 정보>")
	fmt.Printf("인식된 폴더 : %s\n", folders)
	fmt.Printf("keyfile size : %d, [filekeys] len : %d, [filenames] len : %d\n", len(keyfile), len(filekeys), len(filenames))
	fmt.Println("<보안 정보>")
	fmt.Printf("PW : %s\n", string(password))
	fmt.Printf("HINT : %s\n", string(hint))
	fmt.Printf("MSG : %s\n", message)
	fmt.Printf("BOOM : %d\n", boomnum)

	flag := true
	for flag {
		fmt.Println("\nrst (reset PW)   rwr (rewrite MSG)    rsz (resize BOOM)")
		order := input(">>> ")
		switch order {
		case "rst":
			password = []byte(input("new PW : "))
			hint = []byte(input("new HINT : "))
		case "rwr":
			message = input("new MSG : ")
		case "rsz":
			temp := input("new BOOM size (N/KMG) : ")
			temp = strings.ToLower(temp)
			multi := 1
			switch temp[len(temp)-1] {
			case 'k':
				multi = 1024
				temp = temp[0 : len(temp)-1]
			case 'm':
				multi = 1048576
				temp = temp[0 : len(temp)-1]
			case 'g':
				multi = 1073741824
				temp = temp[0 : len(temp)-1]
			default:
				multi = 1
			}
			bnum, err := strconv.Atoi(temp)
			if err == nil {
				boomnum = bnum * multi
			} else {
				fmt.Println("잘못된 숫자.")
			}
		default:
			flag = false
		}
	}
	ioutil.WriteFile("settings.webp", pkgsetting(), 0666)
	printlate("saving config", 0.5)
	fmt.Println("")
}

// clear
func fclear() {
	todel0 := make([]string, 0) // 드라이브에서 삭제
	todel1 := make([]string, 0) // 키 저장소에서 삭제
	for _, r := range folders {
		tr := r + "_en"
		fs, _ := ioutil.ReadDir("./" + tr)
		for _, l := range fs {
			fn := l.Name()
			if _, isin := filekeys[r+"/"+fn]; !isin {
				todel0 = append(todel0, "./"+tr+"/"+fn)
			}
		}

		tr = r + "_de"
		fs, _ = ioutil.ReadDir("./" + tr)
		for _, l := range fs {
			fn := l.Name()
			todel0 = append(todel0, "./"+tr+"/"+fn)
		}
	}

	for i := range filekeys {
		pos := strings.Index(i, "/")
		_, err := os.Stat(i[0:pos] + "_en/" + i[pos+1:])
		if err != nil {
			todel1 = append(todel1, i)
		}
	}

	for _, r := range todel0 {
		os.Remove(r)
	}
	for _, r := range todel1 {
		delete(filekeys, r)
	}
	fmt.Printf("파일삭제 : %d 개, 키삭제 : %d 개\n", len(todel0), len(todel1))
}

// import
func fimport() {
	toadd := make([]string, 0)
	for _, r := range folders {
		tr := r + "_de"
		fs, _ := ioutil.ReadDir("./" + tr)
		for _, l := range fs {
			fn := l.Name()
			if _, isin := filekeys[r+"/"+fn]; !isin {
				toadd = append(toadd, r+"/"+fn)
			}
		}
	}

	tbox := kaes.Init3()
	for _, r := range toadd {
		key := kaes.Genrandom(48)
		pos := strings.Index(r, "/")
		fo := r[0:pos]
		fn := r[pos+1:]
		tbox.En(key, fo+"_de/"+fn, fo+"_en/"+fn)
		filekeys[r] = key
		fmt.Printf("추가 : %s (%s -> %s)\n", r, fo+"_de/"+fn, fo+"_en/"+fn)
	}
	ioutil.WriteFile("settings.webp", pkgsetting(), 0666)
}

// export N
func fexport(n int) {
	tbox := kaes.Init3()
	name := filenames[n]
	pos := strings.Index(name, "/")
	fo := name[0:pos]
	fn := name[pos+1:]
	tbox.De(filekeys[name], fo+"_en/"+fn, fo+"_de/"+fn)
	fmt.Printf("추출 : %s (%s -> %s)\n", name, fo+"_en/"+fn, fo+"_de/"+fn)
}

// export *
func fexportall() {
	for i := range filenames {
		fexport(i)
	}
}

// status
func fstatus() {
	count := 0
	todel := make([]string, 0)
	filenames = make([]string, 0)
	fmt.Println("========== keys start ==========")
	for _, r := range folders {
		tr := r + "_en"
		fs, _ := ioutil.ReadDir("./" + tr)
		for _, l := range fs {
			fn := l.Name()
			if _, isin := filekeys[r+"/"+fn]; isin {
				if count%3 == 2 {
					fmt.Printf("%04d %-19s\n", count, r+"/"+fn)
				} else {
					fmt.Printf("%04d %-19s   ", count, r+"/"+fn)
				}
				filenames = append(filenames, r+"/"+fn)
				count = count + 1
			} else {
				todel = append(todel, "./"+tr+"/"+fn)
			}
		}
	}
	for _, r := range todel {
		os.Remove(r)
	}
	if count != 0 && count%3 != 0 {
		fmt.Println("")
	}
	fmt.Println("========== keys end ==========")
	fmt.Printf("폴더 : %d 개, 파일 : %d 개, 자동삭제 : %d 개\n", len(folders), count, len(todel))
}

// boom
func fboom() {

}

func main() {
	enc := finit()
	ti := 1
	for ti == 1 {
		ti = readpkg(enc)
	}
	fclear()
	fstatus()
	for ti == 0 {
		order := interpret()
		if order != nil {
			switch order[0] {
			case "send":
				tj, _ := strconv.Atoi(order[1])
				if 0 <= tj && tj < len(filekeys) {
					fsend(tj)
				}
			case "view":
				tj, _ := strconv.Atoi(order[1])
				if 0 <= tj && tj < len(filekeys) {
					fview(tj)
				}
			case "config":
				fconfig()
			case "clear":
				fclear()
			case "import":
				fimport()
			case "export":
				if order[1] == "*" {
					fexportall()
				} else {
					tj, _ := strconv.Atoi(order[1])
					if 0 <= tj && tj < len(filekeys) {
						fexport(tj)
					}
				}
			case "status":
				fstatus()
			case "boom":
				fboom()
			default:
				ti = 1
			}
		}
	}
	printlate("종료합니다", 0.7)
}

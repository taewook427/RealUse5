# test605 : kboom (v2py)

import io
import time
import random
import os
import shutil
import zlib

import tkinter
import tkinter.ttk
import tkinter.messagebox
from tkinter import filedialog
from PIL import Image, ImageTk

import threading as thr
import multiprocessing as mp

import kdb
import kaes
import kcom

# 최초 초기화
def finit():
    global folders
    folders = [ ]
    for i in os.listdir("./"):
        if os.path.isdir(i) and len(i) > 3:
            if i[-3:] == "_en":
                if os.path.exists(i[0:-3] + "_de"):
                    folders.append( i[0:-3] )
    if os.path.exists("settings.webp"):
        with open("settings.webp", "rb") as f:
            temp = f.read()
    else:
        temp = pkgset()
        with open("settings.webp", "wb") as f:
            f.write(temp)
    return temp

# 세팅 파일 패키징
def pkgset():
    tbox0 = kdb.toolbox()
    tbox1 = kaes.genbytes()
    tbox1.msg = "Kboom5 settings file"

    temp = ["msg = 0", "boom = 0", "num = 0"]
    for i in range( 0, len(filekeys) ):
        temp.append(f"{i}.name = 0")
        temp.append(f"{i}.key = 0")
    tbox0.readstr( "\n".join(temp) )

    tbox0.fixdata("msg", message)
    tbox0.fixdata("boom", boomnum)
    tbox0.fixdata( "num", len(filekeys) )
    count = 0
    for i in filekeys:
        tbox0.fixdata(f"{count}.name", i)
        tbox0.fixdata( f"{count}.key", filekeys[i] )
        count = count + 1
    temp = tbox0.writestr()

    return tbox1.en( password, keyfile, hint, bytes(temp, encoding="utf-8") )

# 세팅 파일 읽기 (0 : 성공, 1 : 실패)
def readpkg(enc, stpoint):
    tbox0 = kdb.toolbox()
    tbox1 = kaes.genbytes()
    global filekeys
    global filenames
    filekeys = dict()
    filenames = [ ]

    try:
        global message
        global boomnum
        temp = str(tbox1.de(password, keyfile, enc, stpoint), encoding="utf-8")
        tbox0.readstr(temp)
        message = tbox0.getdata("msg")[3]
        boomnum = tbox0.getdata("boom")[3]
        num = tbox0.getdata("num")[3]
        for i in range(0, num):
            tnm = tbox0.getdata(f"{i}.name")[3]
            tky = tbox0.getdata(f"{i}.key")[3]
            filekeys[tnm] = tky
        return 0
    except:
        return 1

# 사진 전송
def transmit(port, enc, crc, name, ret):
    chunk = 102400 # 전송 단위 100KiB
    res = ""
    try:
        buffer = [ ]
        num = len(enc) // chunk
        for i in range(0, num):
            buffer.append( enc[chunk * i:chunk * i + chunk] )
        buffer.append( enc[chunk * num:] )

        tbox = kcom.server()
        tbox.port = port
        tbox.close = 90
        tbox.msg = f"{name}\n{len(buffer)}\n{len(enc)}\n{crc}"
        tbox.send(b"")

        for i in buffer:
            time.sleep(0.03)
            tbox.send(i)
        res = "transmit success"
    except Exception as e:
        res = str(e)
    ret[0] = res

# 클리어
def fclear():
    todel0 = [ ] # 드라이브에서 삭제
    todel1 = [ ] # 키 저장소에서 삭제
    for i in folders:
        for j in os.listdir(i + "_en"):
            if f"{i}/{j}" not in filekeys:
                todel0.append(f"./{i}_en/{j}")
        for j in os.listdir(i + "_de"):
            todel0.append(f"./{i}_de/{j}")
    for i in filekeys:
        pos = i.find("/")
        if not os.path.exists( i[0:pos] + "_en/" + i[pos + 1:] ):
            todel1.append(i)
    for i in todel0:
        os.remove(i)
    for i in todel1:
        del filekeys[i]
    return [ len(todel0), len(todel1) ]

# 가져오기
def fimp():
    toadd = [ ]
    for i in folders:
        for j in os.listdir(i + "_de"):
            if f"{i}/{j}" not in filekeys:
                toadd.append(f"{i}/{j}")
    tbox = kaes.funcfile()
    for i in toadd:
        key = kaes.genrandom(48)
        pos = i.find("/")
        fo = i[0:pos]
        fn = i[pos + 1:]
        tbox.en(key, fo+"_de/"+fn, fo+"_en/"+fn)
        filekeys[i] = key
    return len(toadd)

# 내보내기
def fexp(nums):
    tbox = kaes.funcfile()
    for i in nums:
        name = filenames[i]
        pos = name.find("/")
        fo = name[0:pos]
        fn = name[pos + 1:]
        tbox.de(filekeys[name], f"{fo}_en/{fn}", f"{fo}_de/{fn}")

# 붐
def fboom():
    count0 = 0 # 현재 폴더 지우기 성공수
    count1 = 0 # 실패수
    count2 = boomnum # 남은 덮어쓰기 크기
    for i in os.listdir("./"):
        try:
            if os.path.isdir(i):
                shutil.rmtree(i)
            else:
                os.remove(i)
            count0 = count0 + 1
        except:
            count1 = count1 + 1
    flag = True
    while flag:
        size = count2 // 2
        try:
            with open(f"{size}.bin", "wb") as f:
                f.write(b"\xff" * size)
            count2 = count2 - size
            if count2 < 512:
                flag = False
        except:
            flag = False
    try:
        with open(f"final.bin", "wb") as f:
            f.write(b"\x00" * count2)
        count2 = 0
    except:
        pass
    return f" 현재 폴더 안의 항목 {count0 + count1} 개 중 \n {count0} 개 삭제 성공, {count1} 개 삭제 실패 \n 덮어쓰기 실패 : {count2} / {boomnum} "

# 로그인
def login(enc):
    # 힌트 뷰어
    global hint
    tbox = kaes.genbytes()
    try:
        hint, msg, stpoint = tbox.view(enc)
    except:
        hint = bytes("올바른 설정파일 아님", encoding="utf-8")
        stpoint = 0

    # 로그인 윈도우
    win = tkinter.Tk()
    win.title('Kboom5')
    win.geometry("300x150+100+50")
    win.resizable(False, False)

    # 프로그램 검증
    v0 = kaes.genbytes()
    v1 = kaes.genfile()
    v2 = kaes.funcbytes()
    v3 = kaes.funcfile()
    if not (v0.valid and v1.valid and v2.valid and v3.valid):
        tkinter.messagebox.showinfo(title='심각한 보안 경고', message=' 네이티브 가속 공유 라이브러리 파일이 \n 유효하지 않습니다. (dll/so) ')

    def resetkf():
        time.sleep(0.1)
        global keyfilepath
        global keyfile
        nonlocal strvar1
        try:
            temp = filedialog.askopenfile(title='파일 선택').name
            with open(temp, "rb") as f:
                keyfile = f.read()
            keyfilepath = temp
            strvar1.set(temp)
        except:
            keyfile = kaes.genkf("기본키파일")
            keyfilepath = "기본키파일"
            strvar1.set("기본키파일")

    def gologin():
        time.sleep(0.1)
        global password
        password = bytes(ent3.get(), encoding="utf-8")
        if readpkg(enc, stpoint) == 0:
            win.destroy()
        else:
            tkinter.messagebox.showinfo(title='wrong PWKF', message=' 비밀번호 또는 키 파일 데이터가 \n 일치하지 않습니다. ')

    but0 = tkinter.Button(win, font=("맑은 고딕", 12), text=". . .", command=resetkf)
    but0.place(x=5, y=5) # kf reset
    strvar1 = tkinter.StringVar()
    strvar1.set(keyfilepath)
    ent1 = tkinter.Entry(win, textvariable=strvar1, font=("맑은 고딕", 14), width=23, state="readonly")
    ent1.place(x=55, y=10) # kf path
    lbl2 = tkinter.Label( win, font=("맑은 고딕", 14), text=str(hint, encoding="utf-8") )
    lbl2.place(x=5, y=55) # hint
    ent3 = tkinter.Entry(win, font=("맑은 고딕", 14), width=22, show="*")
    ent3.place(x=5, y=100) # pw input
    but4 = tkinter.Button(win, font=("맑은 고딕", 14), text=" Go ", command=gologin)
    but4.place(x=240, y=95)

    win.mainloop()

# GUI
def main():
    def sendfunc(): # fr0 보내기
        time.sleep(0.1)
        port = random.randrange(10000, 40000)
        key = kaes.genrandom(4)
        realkey = key * 12
        addr = kcom.pack(port, key)
        tbox = kaes.funcbytes()

        name = filenames[ listbox.curselection()[0] ]
        pos = name.find("/")
        with open(name[0:pos] + "_en/" + name[pos + 1:], "rb") as f:
            data = f.read()
        data = tbox.de(filekeys[name], data)
        crcv = zlib.crc32(data)
        enc = tbox.en(realkey, data)

        ret = [""]
        x = thr.Thread( target=transmit, args=(port, enc, crcv, "Kboom5/" + name, ret) )
        x.start()
        tkinter.messagebox.showinfo(title='전송 시작', message=f' 90초 안에 다음 주소를 \n 수신 프로그램에 입력하세요. \n {addr} ')
        x.join()
        tkinter.messagebox.showinfo(title='전송 결과', message=" " + ret[0] + " ")
        regen()

    def impfunc(): # fr0 가져오기
        time.sleep(0.1)
        res0 = fimp()
        res1 = fclear()
        temp = pkgset()
        with open("settings.webp", "wb") as f:
            f.write(temp)
        tkinter.messagebox.showinfo(title='import files', message=f' 파일 {res0} 개를 가져왔습니다. \n 드라이브 삭제 : {res1[0]} 개, 키 삭제 : {res1[1]} 개 ')
        regen()

    def expfunc(): # fr0 내보내기
        time.sleep(0.1)
        sel = listbox.curselection()
        if len(sel) != 0:
            fexp(sel)
        temp = pkgset()
        with open("settings.webp", "wb") as f:
            f.write(temp)
        tkinter.messagebox.showinfo(title='export files', message=f' 파일 {len(sel)} 개를 내보냈습니다. ')
        regen()

    def boomfunc(): # fr0 붐
        time.sleep(0.1)
        res = fclear()
        if tkinter.messagebox.askokcancel(title='export files', message=f' 드라이브 삭제 : {res[0]} 개, 키 삭제 : {res[1]} 개 \n boom 진행 시 모든 키 파일이 삭제되고 \n 저장소가 {boomnum} 바이트만큼 \n 덮어씌워집니다. 계속하시겠습니까? '):
            try:
                res = fboom()
            except Exception as e:
                res = str(e)
            tkinter.messagebox.showinfo(title='BOOM complete', message=f'{res}')
        regen()

    def viewfunc(): # fr1 view
        nonlocal cnvimg
        try:
            temp = filenames[ listbox.curselection()[0] ]
            pos = temp.find("/")
            tgt = temp[0:pos] + "_en/" + temp[pos + 1:]
            with open(tgt, "rb") as f:
                tdata = f.read()
            tbox = kaes.funcbytes()
            idata = tbox.de(filekeys[temp], tdata)

            pimg = Image.open( io.BytesIO(idata) )
            iw, ih = pimg.size
            ratio = min(320 / iw, 320 / ih)
            sw, sh = int(iw * ratio), int(ih * ratio)
            rimg = pimg.resize( (sw, sh), Image.LANCZOS )
            cnvimg = ImageTk.PhotoImage(rimg)
            canvas.create_image(5, 5, anchor=tkinter.NW, image=cnvimg)
        except:
            pass

    def resetcfg(): # 설정 재설정
        time.sleep(0.1)
        global message
        global boomnum
        message = tbox0.get('1.0', tkinter.END)[0:-1]
        boomnum = int( ent1.get() )
        multi = 1
        temp = cbox1.get().lower()[0]
        if temp == "b":
            multi = 1
        elif temp == "k":
            multi = 1024
        elif temp == "m":
            multi = 1048576
        elif temp == "g":
            multi = 1073741824
        boomnum = boomnum * multi

        temp = pkgset()
        with open("settings.webp", "wb") as f:
            f.write(temp)
        tkinter.messagebox.showinfo(title='config update', message=' 메세지/boom 설정이 \n 업데이트되었습니다. ')
        regen()

    def resetpw(): # 비밀번호 재설정
        time.sleep(0.1)
        global message
        global boomnum
        message = tbox0.get('1.0', tkinter.END)[0:-1]
        boomnum = int( ent1.get() )
        multi = 1
        temp = cbox1.get().lower()[0]
        if temp == "b":
            multi = 1
        elif temp == "k":
            multi = 1024
        elif temp == "m":
            multi = 1048576
        elif temp == "g":
            multi = 1073741824
        boomnum = boomnum * multi

        global password
        global hint
        if chkvar.get() != 0:
            password = bytes(ent3.get(), encoding="utf-8")
        hint = bytes(ent4.get(), encoding="utf-8")

        temp = pkgset()
        with open("settings.webp", "wb") as f:
            f.write(temp)
        tkinter.messagebox.showinfo(title='pwhint update', message=' 메세지/boom/비밀번호/힌트 \n 설정이 업데이트되었습니다. ')
        regen()

    def resetkf(): # 키파일 재설정
        time.sleep(0.1)
        global message
        global boomnum
        message = tbox0.get('1.0', tkinter.END)[0:-1]
        boomnum = int( ent1.get() )
        multi = 1
        temp = cbox1.get().lower()[0]
        if temp == "b":
            multi = 1
        elif temp == "k":
            multi = 1024
        elif temp == "m":
            multi = 1048576
        elif temp == "g":
            multi = 1073741824
        boomnum = boomnum * multi

        global password
        global hint
        if chkvar.get() != 0:
            password = bytes(ent3.get(), encoding="utf-8")
        hint = bytes(ent4.get(), encoding="utf-8")

        global keyfile
        global keyfilepath
        try:
            temp = filedialog.askopenfile(title='파일 선택').name
            with open(temp, "rb") as f:
                keyfile = f.read()
            keyfilepath = temp
            strvar1.set(temp)
        except:
            keyfile = kaes.genkf("기본키파일")
            keyfilepath = "기본키파일"
            strvar1.set("기본키파일")

        temp = pkgset()
        with open("settings.webp", "wb") as f:
            f.write(temp)
        tkinter.messagebox.showinfo(title='keyfile update', message=' 메세지/boom/비밀번호/힌트/키파일 \n 설정이 업데이트되었습니다. ')
        regen()

    def pwshow(): # 비밀번호 보기/가리기
        time.sleep(0.1)
        if chkvar.get() == 0:
            strvar3.set( "*" * len( str(password, encoding="utf-8") ) )
            ent3.config(state="readonly")
        else:
            strvar3.set( str(password, encoding="utf-8") )
            ent3.config(state="normal")

    def regen(): # status/config 다시보기
        # fr0
        global filenames
        filenames = [ ]
        for i in folders:
            for j in os.listdir(i + "_en"):
                if i + "/" + j in filekeys:
                    filenames.append(i + "/" + j)
        listbox.delete( 0, listbox.size() )
        for i in filenames:
            listbox.insert(listbox.size(), i)

        # fr1
        viewfunc()

        # fr2
        tbox0.delete(1.0, tkinter.END)
        tbox0.insert(1.0, message)
        strvar1.set( str(boomnum) )
        cbox1.set("Bytes")
        strvar2.set(keyfilepath)
        if chkvar.get() == 0:
            strvar3.set( "*" * len( str(password, encoding="utf-8") ) )
        else:
            strvar3.set( str(password, encoding="utf-8") )
        strvar4.set( str(hint, encoding="utf-8") )
        strvar5.set(f"kf size : {len(keyfile)}, folders : {len(folders)}\nfilekeys : {len(filekeys)}, filenames : {len(filenames)}")

        win.update()

    # 메인 윈도우
    win = tkinter.Tk()
    win.title('Kboom5')
    win.geometry("350x380+100+50")
    win.resizable(False, False)

    # 프레임
    notebook = tkinter.ttk.Notebook(win, width=340, height=340)
    notebook.place(x=5, y=5)
    fr0 = tkinter.Frame(win)
    notebook.add(fr0, text="  status  ")
    fr1 = tkinter.Frame(win)
    notebook.add(fr1, text="  view  ")
    fr2 = tkinter.Frame(win)
    notebook.add(fr2, text="  config  ")

    # 사진 보기 연결
    def clickevent(event):
        if notebook.index( notebook.select() ) == 1:
            viewfunc()
    notebook.bind("<<NotebookTabChanged>>", clickevent)

    sendbut = tkinter.Button(fr0, text=" send ", font=("Consolas", 14), command=sendfunc)
    sendbut.place(x=5, y=5) # fr0 보내기
    impbut = tkinter.Button(fr0, text="import", font=("Consolas", 14), command=impfunc)
    impbut.place(x=90, y=5) # fr0 가져오기
    expbut = tkinter.Button(fr0, text="export", font=("Consolas", 14), command=expfunc)
    expbut.place(x=175, y=5) # fr0 내보내기
    boombut = tkinter.Button(fr0, text=" boom ", font=("Consolas", 14), command=boomfunc)
    boombut.place(x=260, y=5) # fr0 붐

    lstfr = tkinter.Frame(fr0)
    lstfr.place(x=5,y=50)
    listbox = tkinter.Listbox(lstfr, width=31,  height=11, font = ("맑은 고딕", 14), selectmode = 'extended')
    listbox.pack(side="left", fill="y")
    scbar = tkinter.Scrollbar(lstfr, orient="vertical")
    scbar.config(command=listbox.yview)
    scbar.pack(side="right", fill="y")
    listbox.config(yscrollcommand=scbar.set) # files listbox

    canvas = tkinter.Canvas(fr1, width=330, height=330)
    canvas.place(x=5, y=5) # fr1 사진창
    cnvimg = None

    tbox0 = tkinter.Text( fr2, width=32, height=3, font=("맑은 고딕", 14) )
    tbox0.place(x=10, y=5) # msg
    lbl1 = tkinter.Label(fr2, font=("맑은 고딕", 14), text="boom")
    lbl1.place(x=5, y=85)
    strvar1 = tkinter.StringVar()
    strvar1.set("")
    ent1 = tkinter.Entry(fr2, font=("맑은 고딕", 14), textvariable=strvar1, width=15)
    ent1.place(x=70, y=90)
    cbox1 = tkinter.ttk.Combobox(fr2, values=["Bytes", "KiB", "MiB", "GiB"], font=("맑은 고딕", 14), width=8, height=4)
    cbox1.place(x=230, y=90)
    cbox1.set("Bytes") # boomnum

    but2 = tkinter.Button(fr2, font=("맑은 고딕", 12), text=". . .", command=resetkf)
    but2.place(x=5, y=125) # kf reset
    strvar2 = tkinter.StringVar()
    strvar2.set("")
    ent2 = tkinter.Entry(fr2, textvariable=strvar2, font=("맑은 고딕", 14), width=27, state="readonly")
    ent2.place(x=55, y=130) # kf path
    chkvar = tkinter.IntVar()
    chkbut = tkinter.Checkbutton(fr2, text="PW 보기", font=("맑은 고딕", 14), variable=chkvar, command=pwshow)
    chkbut.place(x=5, y=165) # pw show
    strvar3 = tkinter.StringVar()
    strvar3.set("")
    ent3 = tkinter.Entry(fr2, textvariable=strvar3, font=("맑은 고딕", 14), state="readonly", width=21)
    ent3.place(x=115, y=170) # pw input
    strvar4 = tkinter.StringVar()
    strvar4.set("")
    lbl4 = tkinter.Label(fr2, font=("맑은 고딕", 14), text="hint")
    lbl4.place(x=5, y=205)
    ent4 = tkinter.Entry(fr2, textvariable=strvar4, font=("맑은 고딕", 14), width=27)
    ent4.place(x=55, y=210) # hint input

    strvar5 = tkinter.StringVar()
    strvar5.set("kf size : 0, folders : 0\nfilekeys : 0, filenames : 0")
    lbl5 = tkinter.Label(fr2, font=("맑은 고딕", 14), textvariable=strvar5)
    lbl5.place(x=5, y=240) # debug info
    but6 = tkinter.Button(fr2, font=("맑은 고딕", 14), text=" 메세지 재설정 ", command=resetcfg)
    but6.place(x=5, y=295) # reset cfg
    but7 = tkinter.Button(fr2, font=("맑은 고딕", 14), text="비밀번호 재설정", command=resetpw)
    but7.place(x=175, y=295) # reset pw

    fclear()
    regen()
    win.mainloop()

if __name__ == "__main__":
    # 전역 변수 설정
    password = b"0000"
    keyfile = kaes.genkf("기본키파일")
    keyfilepath = "기본키파일"
    hint = bytes("초기화 비밀번호 : 0000", encoding="utf-8")
    message = "Kboom5 사용을 환영합니다."
    folders = [ ]
    boomnum = 104857600
    filekeys = dict()
    filenames = [ ]

    # main 실행부
    mp.freeze_support()
    encb = finit()
    login(encb)
    time.sleep(0.5)
    main()
    time.sleep(0.5)

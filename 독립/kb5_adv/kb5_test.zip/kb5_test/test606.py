# test606 : transmit reciever test

import time
import zlib
import io

import tkinter
import tkinter.messagebox
from PIL import Image, ImageTk

import multiprocessing as mp

import kaes
import kcom

def transmit(port, key): # port int, key 48B -> name S, plain B
    tbox = kcom.client()
    tbox.port = port
    tbox.close = 30
    tbox.recieve()
    buffer = tbox.msg.split("\n")

    name = buffer[0]
    repl = int( buffer[1] )
    size = int( buffer[2] )
    enc = [b""] * repl

    for i in range(0, repl):
        time.sleep(0.05)
        enc[i] = tbox.recieve()

    enc = b"".join(enc)
    if len(enc) != size:
        raise Exception(f"size err {len(enc)}/{size}")
    tbox = kaes.funcbytes()
    data = tbox.de(key, enc)
    crcv = zlib.crc32(data)
    if crcv != int( buffer[3] ):
        raise Exception(f"crc err : {crcv} {buffer[3]}")
    return name, data

def main():
    def getdata():
        time.sleep(0.1)
        temp = ent.get()
        port, key = kcom.unpack(temp)
        try:
            name, idata = transmit(port, key)
        except Exception as e:
            name, idata = "error", b""
            tkinter.messagebox.showinfo(title='수신 오류', message=f' {e} ')

        if idata != b"":
            with open(name.replace("/", "_"), "wb") as f:
                f.write(idata)
            try:
                pimg = Image.open( io.BytesIO(idata) )
                iw, ih = pimg.size
                ratio = min(370 / iw, 370 / ih)
                sw, sh = int(iw * ratio), int(ih * ratio)
                rimg = pimg.resize( (sw, sh), Image.LANCZOS )
                nonlocal rpimg
                rpimg = ImageTk.PhotoImage(rimg)
                canvas.create_image(5, 5, anchor=tkinter.NW, image=rpimg)
            except Exception as e:
                tkinter.messagebox.showinfo(title='사진 표시 오류', message=f' {e} ')
        
    win = tkinter.Tk()
    win.title("test606")
    win.geometry("400x500+200+100")
    win.resizable(False, False)

    lbl = tkinter.Label(win, font=("Consolas", 14), text="주소")
    lbl.place(x=5, y=5)
    ent = tkinter.Entry(win, font=("Consolas", 14), width=24)
    ent.place(x=55, y=10)
    but = tkinter.Button(win, font=("Consolas", 14), text="recieve", command=getdata)
    but.place(x=310, y=5)

    canvas = tkinter.Canvas(win, width=390, height=390)
    canvas.place(x=5, y=105)
    rpimg = None

    win.mainloop()

if __name__ == "__main__":
    time.sleep(0.5)
    mp.freeze_support()
    main()

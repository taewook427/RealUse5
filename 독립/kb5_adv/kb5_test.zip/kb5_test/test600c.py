import kcom
import time
import simen
import os

port = 12345
key = b"142857"
nm = "a.webp"
with open(nm, "rb") as f:
    d = f.read()
k = simen.toolbox()
k.setkey(key)
d = k.encrypt(d)

buffer = [ ]
n = len(d) // 102400
for i in range(0, n):
    buffer.append( d[102400 * i:102400 * i + 102400] )
buffer.append( d[102400 * n:] )

addr = kcom.pack(port, key)
os.startfile("test600b.py", arguments=addr)

k = kcom.server()
k.port = port
k.msg = f"{nm}\n{len(buffer)}\n{len(d)}"
k.send(b"")
for i in buffer:
    time.sleep(0.05)
    k.send(i)
